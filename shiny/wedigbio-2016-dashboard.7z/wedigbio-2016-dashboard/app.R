###### Set up needed libararies
library(plotly)
library(shinydashboard)
library(lubridate)
library(plyr)
library(jsonlite)

Sys.setenv(TZ='UTC')
eventStart <- as.POSIXct("2016-10-19 12:00:00 UTC")
source("final-agg.R")
##### Environment variables


##################### Define the UI
##
##
##
ui <- dashboardPage(
        dashboardHeader(title = "WeDigBio 2016 Dashboard"),
        ## Sidebar content
        dashboardSidebar(
                sidebarMenu(
                        menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
                        menuItem("Widgets", tabName = "widgets", icon = icon("th")),
                        menuItem("Maps", tabName = "maps", icon = icon("map")),
			menuItem("Download", tabName = "download", icon = icon("download"))
                )
        ),
        
        
        ## Body content
        dashboardBody(
                tabItems(
                        # First tab content
                        tabItem(tabName = "dashboard",
                                fluidRow(         
                                        box(title = "Total Records Transcribed", width = 12, solidHeader = TRUE, status = "primary", plotlyOutput('plot'))
                                ),  
                                fluidRow(         
                                        box(title = "Transcriptions per hour", width = 12, solidHeader = TRUE, status = "primary", plotlyOutput('ratePlot'))
                                ), 
                                fluidRow(         
                                        box(title = "Transcriptions by Center", width = 12, solidHeader = TRUE, status = "primary", plotlyOutput('centerPlot'))
                                ), 
                                fluidRow(         
                                        box(title = "Transcription Activity by Specimen Locality", width = 12, solidHeader = TRUE, status = "primary", HTML("<iframe width='100%' height='520' frameborder='0' src='https://nfn.cartodb.com/viz/b2fdd556-9c7b-11e6-ab45-0ecd1babdde5/embed_map' allowfullscreen webkitallowfullscreen mozallowfullscreen oallowfullscreen msallowfullscreen></iframe>"))
                                )  
                        ),
                        
                        # Widgets tab content
                        tabItem(tabName = "widgets",
                                fluidRow(
                                        valueBoxOutput("progressBox"),
                                        valueBoxOutput("timeBox"),
                                        valueBoxOutput("countBox")
                                ),
                                fluidRow(
                                        valueBoxOutput("rateBox", width=8),
                                        valueBoxOutput("rateTrend", width=4)
                                )
                        ),
                        # Maps tab content
                        tabItem(tabName = "maps",
                                fluidRow(         
                                        box(title = "Transcription Activity by Specimen Locality", width = 12, solidHeader = TRUE, status = "primary", HTML("<iframe width='100%' height='520' frameborder='0' src='https://nfn.cartodb.com/viz/b2fdd556-9c7b-11e6-ab45-0ecd1babdde5/embed_map' allowfullscreen webkitallowfullscreen mozallowfullscreen oallowfullscreen msallowfullscreen></iframe>"))
                                ),  
                                fluidRow(
                                        box(title = "Transcription Activity by Transcriber Locality", width = 12, solidHeader = TRUE, status = "primary",HTML("<iframe width='100%' height='520' frameborder='0' src='https://nfn.cartodb.com/viz/3723426e-9bc1-11e6-a111-0e05a8b3e3d7/embed_map' allowfullscreen webkitallowfullscreen mozallowfullscreen oallowfullscreen msallowfullscreen></iframe>"))
                                )
                        ),
                        # Download tab content
                        tabItem(tabName = "download",
                                fluidRow(         
                                        box(title = "Files", width = 12, solidHeader = TRUE, status = "primary",
					selectInput("dataset", "Choose a dataset:",choices = c("2016")),
					downloadButton('downloadData', 'Download')
					)
                                )
                        )
                )
        )
)        
        
        
        


############## Define the server code
server <- function(input, output,session) {
	datasetInput <- reactive({
                switch(input$dataset,"2016" = ddf)
        })
        output$downloadData <- downloadHandler(
                filename = function() { 
                        paste("WeDigBio-",input$dataset, '.csv', sep='') 
                },
                content = function(file) {
                        write.csv(datasetInput(), file,row.names=F)
                }
        )
        output$plot <- renderPlotly({

	f <- plot_ly(ddf, x = ~time, y = ~cumsum, name = 'All', type = 'scatter', mode='lines',fill = 'tozeroy')%>%
                layout(
                        title = "WeDigBio Total Transcription Activity", 
                        xaxis = list(title = "Elapsed Time in Hours"), 
                        yaxis = list(title = "Total Transcriptions")
                )

        })
        output$ratePlot <- renderPlotly({        

		rate <-aggregate(list(Transcriptions = as.numeric(ddf$discretionaryState.workUnit)),list(Hour = cut(ddf$timestamp, "1 hour")), sum)
        	plot_ly(rate,x= 1:120,y=~Transcriptions,type="scatter",mode="lines")%>%
                layout(
                        title = "WeDigBio Total Transcription Rate (per hour)", 
                        xaxis = list(title = "Elapsed Time in Hours", nticks=6), 
                        yaxis = list(title = "Total Transcriptions")
                )
        }) 
        output$centerPlot <- renderPlotly({        
	p <- plot_ly(trace1, x = ~time, y = ~cumsum, name = 'SITC', type = 'scatter', mode='lines',fill = 'tozeroy')%>%
                add_trace(y = trace2$cumsum, name = 'DigiVol')%>%        
                add_trace(y = trace3$cumsum, name = 'Les herbonautes')%>%
                layout(
                        title = "WeDigBio Total Transcription Activity (by transcription center)", 
                        xaxis = list(title = "Elapsed Time in Hours"), 
                        yaxis = list(title = "Total Transcriptions")
                )



        }) 
        output$progressBox <- renderValueBox({
                totalTranscript <- prettyNum(round(sum(as.numeric(ddf$discretionaryState.workUnit))),big.mark=",")
		valueBox(
                        totalTranscript, "Total Transcriptions", icon = icon("list"),
                        color = "purple"
                )
        })
        output$countBox <- renderValueBox({
                centCount <- length(unique(ddf$center))
		valueBox(
                        centCount, "Transcription Centers Reporting", icon = icon("database"),
                        color = "orange"
                )
        })
        output$timeBox <- renderValueBox({
                span <- round(time_length(ddf$timestamp[length(ddf$timestamp)] -ddf$timestamp[1],unit="hour"),2)
		valueBox(
                        span, paste0("Hours (Event Start: ",eventStart,")"), icon = icon("clock-o"),
                        color = "blue"
                )
        })
        output$rateBox <- renderValueBox({
                rateMin <-aggregate(list(Transcriptions = as.numeric(ddf$discretionaryState.workUnit)),list(Day = cut(ddf$timestamp, "min")), sum)
		avRate <- round(mean(rateMin$Transcriptions),2)
		valueBox(
                        	avRate, "Average Transcription Rate (per minute)", icon = icon("line-chart"),
                        	color = "blue"
                )
                
        })
        output$rateTrend <- renderValueBox({
                rateDif <- 0
                valueBox(
                        rateDif, "Trend over last 15 minutes", icon = icon("arrows-v"),
                        color = if(rateDif <=0){"yellow"}else{"green"}
                )
                
        })
}

# Return a Shiny app object
shinyApp(ui = ui, server = server)
