## Le't figure out this time stuff together!

##Lubridate makes working with dates easy!
library(lubridate)


## First we need to set our system tize zone to UTC
Sys.setenv(TZ='UTC')

##Define a function for calculating the event start
eventStart <- function(){

        ## We know the event start at the first time zone to see the new day on October 20, 2016
        ## Wikipedia says "According to the clock, the first areas to experience a new day and a New Year are islands that use UTC+14":
        eventStart <- format(as.POSIXct("2016-10-19 10:00:00 UTC") + hours(14),"%Y-%m-%d %H:%M:%S")
        eventStartLocal <- "2016-10-20 00:00:00" 
        identical(eventStart,eventStartLocal)
        #Need to turn it into a date/time object 
        return(as.POSIXct(eventStart))

        }
eventStart()

##Define a function for setting the event end
eventEnd <- function(){
        
        ## It's now easy to find the end date
        ## We can simply add hours or days to the startDate
        eventEnd <- format(as.POSIXct("2016-10-19 10:00:00 UTC") + hours(14)+hours(96),"%Y-%m-%d %H:%M:%S")
        eventEndLocal <- "2016-10-24 00:00:00"
        identical(eventEndLocal,eventEnd)
        
        ##That works! Now let's see how it shakes out by days
        
        eventEnd <- format(as.POSIXct("2016-10-19 10:00:00 UTC") + hours(14)+days(4),"%Y-%m-%d %H:%M:%S")
        identical(eventEndLocal,eventEnd)
        
        ##Turn this into a data/time object
        return(as.POSIXct(eventEnd))
        
        }
eventEnd()


##Lastly, let's validate our duration
eventEnd() - eventStart()
