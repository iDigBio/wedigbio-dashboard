##Set up enviroment
library(jsonlite)
library(plyr)
#library(rgeolocate)
library(plotly)
library(lubridate)

Sys.setenv(TZ='UTC')
eventStart <- as.POSIXct("2016-10-19 12:00:00 UTC")

##This function aggregates raw data 
aggData <- function(){
        sitc <- function(){
                sitc <- flatten(readRDS("data/final-sitcItems.rds"))
                sitc$timestamp <- strptime(sitc$timestamp,format="%Y-%m-%dT%H:%M:%S")
                sitc$center <- "SITC"
                sitc$contributor.physicalLocation.state <- sitc$contributor.physicalLocation.province
                sitc$contributor.physicalLocation.province <- NULL
                sitc$discretionaryState.workUnit <- 1
                return(sitc)
        }
                
        herb <- function(){
                herb <- flatten(readRDS("data/final-herItems.rds"))
                herb$timestamp <- strptime(herb$timestamp,format="%Y-%m-%dT%H:%M:%S")
                herb$center <- "Les herbonautes"
                return(herb)
        }
                
        digi <- function(){
                digi <- flatten(readRDS("data/final-digItems.rds"))
                digi$timestamp <- strptime(digi$timestamp,format="%Y-%m-%dT%H:%M:%S")
                digi$center <- "DigiVol"
                digi$subject.thumbnailUri <-digi$subject.thumbnailUrl
                digi$subject.thumbnailUrl <- NULL
                digi$discretionaryState.workUnit <- 1
                return(digi)
        }
        
        return(rbind.fill(herb(),digi(),sitc()))        
}


##This function aggregates data needed for mapping
aggItems <- function(){
        sitc <- readRDS("data/final-sitcItems.rds")
        sitc$ip <- "NA"
        sitc$center <- "SITC"
        sitc$workUnit <- 1
        sitc <- sitc[c(14,2,4,3,9,10,6,7,1,15,16)]
        names(sitc) <- c("ip","description","timestamp","guid","contriblat","contriblon","subject_link","subject_thumbnailurl","project","center","workUnit")
        
        herb <- readRDS("data/final-herItems.rds")
        herb <- flatten(herb)
        herb$ip <- "NA"
        herb$center <- "Les herbonautes"
        herb <- herb[c(11,2,4,3,7,8,5,6,1,12,10)]
        names(herb) <- c("ip","description","timestamp","guid","contriblat","contriblon","subject_link","subject_thumbnailurl","project","center","workUnit")
        
        digi <- readRDS("data/final-digItems.rds")
        digi$contribLat <- maxmind(digi$contributor.ipAddress,"GeoLite2-City.mmdb",fields = "latitude")$latitude
        digi$contribLon <- maxmind(digi$contributor.ipAddress,"GeoLite2-City.mmdb",fields = "longitude")$longitude
        digi$center <- "DigiVol"
        digi$workUnit <-1
        digi <- digi[c(11,7,5,4,26,27,8,9,3,28,29)]
        names(digi) <- c("ip","description","timestamp","guid","contriblat","contriblon","subject_link","subject_thumbnailurl","project","center","workUnit")
        transItems <- rbind.fill(sitc,digi)
        transItems <- rbind.fill(transItems,herb)
        return(transItems)
}


        ddf <- aggData()
        ddf <- ddf[!duplicated(ddf$guid),]
        Sys.setenv(TZ='UTC')
        eventStart <- as.POSIXct("2016-10-19 12:00:00 UTC")
        ddf$time <- round(as.numeric(ddf$timestamp-eventStart)/60,2)
        
        
        trace1 <- ddf[which(ddf$center == "SITC"),]
        trace1 <-trace1[order(trace1$timestamp),]
        trace1$cumsum <- round(cumsum(trace1$discretionaryState.workUnit))
        trace1 <- trace1[seq(from=1,to=length(trace1$time), length.out = 120),]
        trace2 <- ddf[which(ddf$center == "DigiVol"),]
        trace2 <-trace2[order(trace2$timestamp),]
        trace2$cumsum <- round(cumsum(trace2$discretionaryState.workUnit))
        trace2 <- trace2[seq(from=1,to=length(trace2$time), length.out = 120),]
        trace3 <- ddf[which(ddf$center == "Les herbonautes"),]
        trace3 <- trace3[order(trace3$timestamp),]
        trace3$cumsum <- round(cumsum(trace3$discretionaryState.workUnit))
        trace3 <- trace3[seq(from=1,to=length(trace3$time), length.out = 120),]

        p <- plot_ly(trace1, x = ~time, y = ~cumsum, name = 'SITC', type = 'scatter', mode='lines',fill = 'tozeroy')%>%
                add_trace(y = trace2$cumsum, name = 'DigiVol')%>%        
                add_trace(y = trace3$cumsum, name = 'Les herbonautes')%>%
                layout(
                        autosize = TRUE, 
                        barmode = "group", 
                        height = 845, 
                        #legend = list(xanchor = "auto"), 
                        paper_bgcolor = "rgb(203, 203, 203)", 
                        plot_bgcolor = "rgb(204, 204, 204)", 
                        title = "WeDigBio Total Transcription Activity", 
                        width = 1984, 
                        xaxis = list(title = "Elapsed Time in Hours"), 
                        yaxis = list(title = "Total Transcriptions")
                )
        #p
        #plotly_POST(p, filename = "wdb-dev")
        
        
        ddf <- ddf[order(ddf$timestamp),]
        ddf$cumsum <- round(cumsum(ddf$discretionaryState.workUnit))
        f <- plot_ly(ddf, x = ~time, y = ~cumsum, name = 'SITC', type = 'scatter', mode='lines',fill = 'tozeroy')%>%
                layout(
                        autosize = TRUE, 
                        barmode = "group", 
                        height = 845, 
                        #legend = list(xanchor = "auto"), 
                        paper_bgcolor = "rgb(203, 203, 203)", 
                        plot_bgcolor = "rgb(204, 204, 204)", 
                        title = "WeDigBio Total Transcription Activity", 
                        width = 1984, 
                        xaxis = list(title = "Elapsed Time in Hours"), 
                        yaxis = list(title = "Total Transcriptions")
                )
